    <span class="form-control code fw-bold" style="color: black" type="text">{{ $data->order_number }}<a href="#"
            class="copy_code">
            <i class="icofont  icofont-ui-copy"></i></a></span>
