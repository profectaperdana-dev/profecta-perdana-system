<style>
    .table-sm {
        background-color: rgba(211, 225, 222, 255);
        -webkit-print-color-adjust: exact;
    }

    /* .table.dataTable table,
    th,
    td {

        vertical-align: middle !important;
    } */

    .select2-selection__clear {
        margin-top: -5px !important;
        font-size: 18pt !important;
        color: rgb(255, 139, 139) !important;
    }

    .select2-selection__choice__remove {
        display: none !important;
    }

    .select2-search__field {
        padding-bottom: 22px !important;
    }

    .select2-selection--multiple {
        padding: 5px 5px 5px 5px !important;
    }

    .select2-selection__choice {
        padding: 2px 6px !important;
        margin-top: 0 !important;
        background-color: #e2c636 !important;
        border-color: #e2c636 !important;
        color: #fff;
        margin-right: 8px !important;
    }
</style>
