<div class="ribbon-wrapper card">
    <div class="card-body">
        <div class="ribbon ribbon-bookmark ribbon-primary">Data Lain-lain / <i>Other Data</i></div>
        <input type="hidden" value="{{ url()->current() }}" name="link">

        {{-- ! SEKOLAH --}}
        <div class="row font-weight-bold">
            {{-- ! sekolah 1 --}}
            <div class="form-group row">
                <h5>Kegiatan Diwaktu Luang / <i>Leisure Time Activities
                    </i></h5>
                <hr class="bg-primary">
                <div class="col-md-1 form-group">
                    <label><span class="text-danger">* </span> No / <i> No </i></label>
                    <input style="background-color: #3db39d" type="text" name="" readonly value="1"
                        class="form-control text-center text-white text-capitalize tab-3" placeholder="Ayah / Father"
                        required>
                </div>
            </div>

        </div>

    </div>
</div>
