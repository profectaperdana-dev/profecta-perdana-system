<div class="col-xl-12 box-col-12 des-xl-100">
    <div class="row">
        <div class="col-xl-8 box-col-12">
            <div class="card">
                <div class="card-header">
                    <div class="header-top d-sm-flex justify-content-between align-items-center">
                        <h5>last 7 days sale</h5><br>
                        {{-- <div class="center-content">
                            <ul class="week-date">
                                <li class="font-primary">Today</li>
                                <li>Month </li>
                            </ul>
                        </div> --}}
                    </div>
                </div>
                <div class="card-body chart-block p-0">
                    {{-- <div id="chart-dash-2-line"></div> --}}
                    <div class="chart-container">
                        <div class="row">
                            <div class="col-12">
                                <div id="chart-dash-2-line"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 box-col-12">
            <div class="card">
                <div class="cal-date-widget card-body">
                    <div class="row">
                        <div class="col-xl-12 col-xs-12 col-md-12 col-sm-12">
                            <div class="cal-datepicker">
                                <div class="datepicker-here" data-language="en"> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
